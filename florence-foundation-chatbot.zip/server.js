const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));
app.use(express.static(path.join(__dirname, 'public')));

// Simple rule-based matcher
function loadIntents() {
  const raw = fs.readFileSync(path.join(__dirname, 'data', 'intents.json'), 'utf8');
  return JSON.parse(raw).intents;
}
const INTENTS = loadIntents();

function normalize(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
}

function matchIntent(message) {
  const msg = normalize(message);
  let best = { tag: 'fallback', score: 0 };

  for (const intent of INTENTS) {
    let score = 0;
    for (const p of intent.patterns || []) {
      const pattern = normalize(p);
      if (!pattern) continue;
      if (msg.includes(pattern)) {
        // Exact substring hit = high score
        score += Math.min(pattern.length / Math.max(msg.length, 1), 1) * 2;
      } else {
        // Token overlap score
        const msgTokens = new Set(msg.split(' '));
        const patTokens = new Set(pattern.split(' '));
        let overlap = 0;
        for (const t of patTokens) if (msgTokens.has(t)) overlap++;
        score += overlap / Math.max(patTokens.size, 1);
      }
    }
    if (score > best.score) best = { tag: intent.tag, score, intent };
  }
  return best.intent || INTENTS.find(i => i.tag === 'fallback');
}

// API: chat endpoint
app.post('/api/chat', (req, res) => {
  const { message } = req.body || {};
  if (!message) return res.status(400).json({ error: 'message is required' });

  const intent = matchIntent(message);
  const responses = intent.responses || [];
  const reply = responses[Math.floor(Math.random() * responses.length)] || "Sorry, I didn't get that.";
  res.json({ reply, intent: intent.tag });
});

// Health check
app.get('/api/health', (_req, res) => res.json({ ok: true }));

// Fallback to index.html for root
app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Florence Foundation server running at http://localhost:${PORT}`);
});