# Florence Foundation with ChatBot Implementation

A minimal website for **Florence Foundation** with a built-in **rule-based chatbot** using **Node.js + Express** and vanilla HTML/CSS/JS.

## Features
- Responsive landing page with a clean chat UI
- Rule-based chatbot using a simple keyword matcher
- Easy to extend by editing `data/intents.json`
- API endpoint: `POST /api/chat`

## Project Structure
```
florence-foundation-chatbot/
├─ data/
│  └─ intents.json         # Patterns and responses
├─ public/
│  ├─ index.html           # Frontend
│  ├─ styles.css           # Styling
│  └─ app.js               # Chat logic (fetches /api/chat)
├─ .gitignore
├─ package.json
├─ server.js               # Express server
└─ README.md
```

## Local Setup
1. Install Node.js (v18+ recommended).
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run the server:
   ```bash
   npm start
   ```
4. Open http://localhost:3000 in your browser.

## Deploy
- **GitHub**: Initialize and push
  ```bash
  git init
  git add .
  git commit -m "Initial commit: Florence Foundation chatbot"
  git branch -M main
  git remote add origin https://github.com/<your-username>/florence-foundation-chatbot.git
  git push -u origin main
  ```
- **Render/Heroku/Fly.io**: Create a new Node web service, set `Start Command` to `npm start`.

## Customize
- Update organization details in `data/intents.json` (contact, address, etc.).
- Add new intents:
  ```json
  {
    "tag": "scholarships",
    "patterns": ["scholarship", "financial aid"],
    "responses": ["We offer need-based scholarships; applications open each June."]
  }
  ```
- Improve matching: Implement NLP or connect to an AI provider.

## Optional: Switch to AI-based replies
Replace `/api/chat` logic with calls to your preferred LLM API. Keep the same response schema `{ reply, intent }` so the frontend stays unchanged.

## License
MIT