const chatWindow = document.getElementById('chat-window');
const form = document.getElementById('chat-form');
const input = document.getElementById('user-input');
const yearEl = document.getElementById('year');

yearEl.textContent = new Date().getFullYear();

function addMessage(role, text) {
  const row = document.createElement('div');
  row.className = `message ${role}`;
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.textContent = text;
  row.appendChild(bubble);
  chatWindow.appendChild(row);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

addMessage('bot', "Hello! I’m Florence Bot. Ask me about our programs, donations, volunteering, or contact details.");

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const content = input.value.trim();
  if (!content) return;
  addMessage('user', content);
  input.value = '';
  form.querySelector('button').disabled = true;
  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: content })
    });
    if (!res.ok) throw new Error('Network error');
    const data = await res.json();
    addMessage('bot', data.reply || "Sorry, I didn't get that.");
  } catch (err) {
    addMessage('bot', 'Oops, something went wrong. Please try again.');
    console.error(err);
  } finally {
    form.querySelector('button').disabled = false;
    input.focus();
  }
});